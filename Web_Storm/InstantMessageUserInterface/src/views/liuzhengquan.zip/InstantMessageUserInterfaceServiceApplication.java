package cn.liuzhengquan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InstantMessageUserInterfaceServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(InstantMessageUserInterfaceServiceApplication.class, args);
    }

}
