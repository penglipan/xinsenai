<template>
  <div>
    <el-button type="primary">Primary</el-button>
    <el-button type="success">Success</el-button>
  </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>