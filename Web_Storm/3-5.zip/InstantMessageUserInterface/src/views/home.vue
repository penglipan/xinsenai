<template>
  <!--首页-->
  <div class="home">
    <!--容器-->
    <div class="container">
      <!--布局-->
      <el-row class="layout">
        <el-col :span="2">
          <!--选项-->
          <div class="grid-content options">
            <!--网络-->
            <div class="network">
              <div></div>
              <div></div>
              <div></div>
            </div>

            <!--头像-->
            <div class="avatar">
              <img src="@/assets/image/theme/login/avatar.png" alt="">
              <!--在线状态-->
              <div class="online-state"></div>
            </div>

            <!--功能-->
            <div class="feature">
              <!--选项-->
              <!--消息-->
              <div class="option">
                <el-icon>
                  <Comment/>
                </el-icon>
              </div>
              <!--用户/好友-->
              <div class="option">
                <el-icon>
                  <Avatar/>
                </el-icon>
              </div>
              <!--钱包-->
              <div class="option">
                <el-icon>
                  <WalletFilled/>
                </el-icon>
              </div>
              <!--设置-->
              <div class="settings">
                <el-icon>
                  <Tools/>
                </el-icon>
              </div>
            </div>
          </div>
        </el-col>

        <el-col :span="6">
          <!--好友消息-->
          <div class="grid-content friends-message">
            <!--导航-->
            <div class="navigation">
              <!--搜索-->
              <div class="search">
                <el-input
                    v-model="search"
                    placeholder=""
                    size="small"
                    :prefix-icon="Search"
                />
              </div>
              <!--添加-->
              <div class="add">
                <el-icon>
                  <CirclePlusFilled/>
                </el-icon>
              </div>
            </div>
            <!--好友消息列表无限滚动-->
            <div class="infinite-scroll" v-infinite-scroll="loadFriendsMessageInfiniteScroll">
              <!--好友-->
              <div class="friend">
                <!--头像-->
                <div class="avatar">
                  <img src="@/assets/image/theme/login/other.png" alt="">
                </div>
                <!--好友消息-->
                <div class="message">
                  <!--昵称/账号-->
                  <div class="nickname">
                    <div>霸道总裁喵</div>
                    <!--徽章-->
                    <div class="badge">
                      99
                    </div>
                  </div>
                  <!--最新通知消息-->
                  <div class="latest-notice-news">
                    最新通知消息......
                    <!--最新通知消息最新通知消息最新通知消息最新通知消息-->
                  </div>
                </div>
              </div>
            </div>
          </div>
        </el-col>

        <el-col :span="16">
          <!--聊天-->
          <div class="grid-content chats">
            <!--顶部-->
            <div class="top">
              <!--昵称/账号-->
              <div class="nickname">
                霸道总裁喵
              </div>
              <!--在线状态-->
              <div class="status">
                <!--状态-->
                <div class="state"></div>
                <!--在线或离线-->
                <div class="online-or-offline">在线</div>
              </div>
            </div>
            <!--聊天-->
            <div class="chat">
              <!--聊天消息列表无限滚动-->
              <div class="infinite-scroll" v-infinite-scroll="loadFriendsMessageInfiniteScroll">
                <!--左边-->
                <div class="left">
                  <!--头像-->
                  <div class="avatar">
                    <img src="@/assets/image/theme/login/other.png" alt="">
                  </div>
                  <!--消息-->
                  <div class="message">
                    你好啊~
                    <!--三角形-->
                    <div class="triangle"></div>
                  </div>
                </div>
                <!--右边-->
                <div class="right">
                  <!--消息-->
                  <div class="message">
                    你好啊~
                    <!--三角形-->
                    <div class="triangle"></div>
                  </div>
                  <!--头像-->
                  <div class="avatar">
                    <img src="@/assets/image/theme/login/avatar.png" alt="">
                  </div>
                </div>
              </div>
            </div>
            <!--底部-->
            <div class="bottom">
              <!--左边-->
              <div class="left">
                <!--表情包-->
                <div class="emoji">
                  <img src="@/assets/image/theme/home/svg/smile.svg" alt="">
                </div>
                <!--文件-->
                <div class="file">
                  <el-icon>
                    <FolderOpened/>
                  </el-icon>
                </div>
              </div>
              <!--中间-->
              <div class="middle">
                <el-input v-model="message" placeholder="现在可以开始聊天了"/>
              </div>
              <!--右边-->
              <div class="right">
                <el-icon>
                  <Promotion/>
                </el-icon>
              </div>
            </div>
          </div>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script setup lang="ts">
import {ref} from 'vue'
import {
  Promotion,
  FolderOpened,
  CirclePlusFilled,
  Search,
  Tools,
  WalletFilled,
  Avatar,
  Comment
} from "@element-plus/icons-vue";

const search = ref('')
const message = ref('')

const loadFriendsMessageInfiniteScroll = () => {

}
</script>

<style lang="scss" scoped>

// 底部
.bottom {
  display: flex;
  width: 100%;
  height: 48px;
  font-size: 14px;
  align-items: center;
  justify-content: space-evenly;
  background: #F7FCFF;
  border-radius: 0 0 4px 0;

  // 左边
  .left {
    display: flex;
    align-items: center;
    justify-content: center;
    // 表情包
    .emoji {
      width: 28px;
      height: 28px;
      cursor: pointer;
      margin-right: 12px;

      img {
        width: 100%;
        height: 100%;
      }
    }

    // 文件
    .file {
      display: flex;
      color: #A9ACAF;
      cursor: pointer;
      font-size: 28px;
      font-weight: 400;
      align-items: center;
      justify-content: center;
    }
  }

  // 中间
  .middle {
    width: 80%;

    :deep(.el-input__inner) {
      color: #000;
      font-weight: 600;
      font-family: "Alimama DongFangDaKai", serif;
    }
  }

  // 右边
  .right {
    display: flex;
    color: #A9ACAF;
    cursor: pointer;
    font-size: 28px;
    font-weight: 400;
    align-items: center;
    justify-content: center;
  }

  .right:hover {
    color: #409eff;
  }
}

// 聊天
.chats {
  display: flex;
  width: 100%;
  align-items: center;
  flex-direction: column;
  border-radius: 0 4px 4px 0;
  background: #EFF3F6;
  // 顶部
  .top {
    display: flex;
    width: 100%;
    height: 48px;
    font-size: 14px;
    align-items: center;
    justify-content: center;
    background: #F7FCFF;
    border-radius: 0 4px 0px 0;

    // 昵称/账号
    .nickname {
      color: #000;
      font-family: "Alimama ShuHeiTi Bold", serif;
    }

    // 在线状态
    .status {
      display: flex;
      align-items: center;
      justify-content: center;
      // 状态
      .state {
        width: 10px;
        height: 10px;
        margin: 0 8px;
        background: #77fd59;
        border-radius: 50%;
      }

      // 在线或者离线
      .online-or-offline {
        color: #606266;
        font-size: 12px;
        font-family: "Alimama DongFangDaKai", serif;
      }
    }

  }

  // 中间聊天
  .chat {
    display: flex;
    width: 100%;
    // 聊天消息列表无限滚动
    .infinite-scroll {
      width: 100%;
      height: 484px;
      overflow: auto;

      // 左边
      .left {
        position: relative;
        display: flex;
        margin-top: 10px;
        align-items: center;
        padding-left: 6px;

        // 头像
        .avatar {
          width: 32px;
          height: 32px;
          margin-right: 6px;
          margin-bottom: 0px;

          img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
          }
        }

        // 消息
        .message {
          position: relative;
          display: flex;
          color: #000;
          height: 24px;
          font-size: 14px;
          padding: 3px 8px;
          background: #ffffff;
          font-family: "Alimama ShuHeiTi Bold", serif;
          border-radius: 4px;
          align-items: center;
          margin-top: 10px;
          margin-left: 8px;
          box-shadow: 0 0 12px rgba(0, 0, 0, .12);
          // 三角形
          .triangle {
            position: absolute;
            border-right: 8px solid #fff;
            border-top: 6px solid transparent;
            border-bottom: 6px solid transparent;
            left: -6px;
            top: 6px;
          }
        }
      }

      // 右边
      .right {
        position: relative;
        display: flex;
        margin-top: 10px;
        align-items: center;
        padding-right: 6px;
        justify-content: flex-end;

        // 头像
        .avatar {
          width: 32px;
          height: 32px;
          margin-left: 6px;
          margin-bottom: 0px;

          img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
          }
        }

        // 消息
        .message {
          position: relative;
          display: flex;
          color: #000;
          height: 24px;
          font-size: 14px;
          padding: 3px 8px;
          background: #55D58B;
          font-family: "Alimama ShuHeiTi Bold", serif;
          border-radius: 4px;
          align-items: center;
          margin-top: 10px;
          margin-right: 8px;
          box-shadow: 0 0 12px rgba(0, 0, 0, .12);
          // 三角形
          .triangle {
            position: absolute;
            border-top: 6px solid transparent;
            border-left: 8px solid #55D58B;
            border-bottom: 6px solid transparent;
            right: -6px;
            top: 6px;
          }
        }
      }
    }
  }
}

// 好友消息
.friends-message {
  display: flex;
  width: 100%;
  align-items: center;
  flex-direction: column;
  background: #363F48 !important;

  // 导航
  .navigation {
    display: flex;
    width: 100%;
    height: 40px;
    align-items: center;
    background: #3A434A;
    justify-content: space-evenly;
    // 搜索
    .search {
      :deep(.el-input__inner) {
        color: #ffffff;
        font-weight: 600;
        font-family: "Alimama DongFangDaKai", serif;
      }

      :deep(.el-input__wrapper) {
        background: #303842;
        border-radius: 50px;
      }
    }

    // 添加好友
    .add {
      display: flex;
      cursor: pointer;
      font-size: 24px;
      align-items: center;
      justify-content: center;
      color: #606266;
    }

    .add:hover {
      color: #ffffff;
    }
  }

  // 好友消息列表无限滚动
  .infinite-scroll {
    width: 100%;
    height: 530px;
    overflow: auto;

    // 好友
    .friend {
      display: flex;
      height: 60px;
      color: #ffffff;
      cursor: pointer;
      align-items: center;
      margin-top: 10px;
      justify-content: space-evenly;

      // 头像
      .avatar {
        display: flex;
        width: 38px;
        height: 38px;
        align-items: center;
        justify-content: center;
        margin-bottom: 0px;

        img {
          width: 100%;
          height: 100%;
          border-radius: 50%;
        }
      }

      // 好友消息
      .message {
        display: flex;
        width: 210px;
        text-align: left;
        flex-direction: column;
        // 昵称/账号
        .nickname {
          display: flex;
          font-size: 12px;
          font-family: "Alimama DongFangDaKai", serif;
          justify-content: space-between;
          // 徽章
          .badge {
            display: flex;
            width: 18px;
            height: 18px;
            font-size: 8px;
            font-family: "Alimama ShuHeiTi Bold", serif;
            background: red;
            border-radius: 50%;
            text-align: center;
            align-items: center;
            justify-content: center;
          }
        }

        // 最新消息通知
        .latest-notice-news {
          width: 210px;
          color: #C0C4CC;
          font-size: 9px;
          font-family: "Alimama DongFangDaKai", serif;
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
        }

      }
    }

    .friend:hover {
      background: #444c56;
    }
  }
}

// 布局
.layout {
  position: relative;
  width: 100%;
  height: 100%;
  // 选项
  .grid-content {
    height: 100%;
    background: #303842;
  }

  .options {
    display: flex;
    width: 100%;
    align-items: center;
    flex-direction: column;
    border-radius: 4px 0 0 4px;
  }

  // 网络状态
  .network {
    display: flex;
    width: 100%;
    margin-top: 20px;
    margin-bottom: 30px;
    justify-content: space-evenly;

    div {
      width: 11px;
      height: 11px;
      border-radius: 50%;
    }

    div:nth-child(1) {
      background: red;
    }

    div:nth-child(2) {
      background: yellow;
    }

    div:nth-child(3) {
      background: green;
    }
  }

  // 头像
  .avatar {
    position: relative;
    width: 84px;
    height: 84px;
    margin-bottom: 35px;

    img {
      width: 100%;
      height: 100%;
      border-radius: 50%;
    }

    // 在线状态
    .online-state {
      position: absolute;
      width: 14px;
      height: 14px;
      right: 6px;
      bottom: 6px;
      background: green;
      border-radius: 50%;
    }
  }

  // 功能
  .feature {
    position: relative;
    display: flex;
    width: 100%;
    height: 100%;
    color: #A6B6C3;

    flex-direction: column;

    // 选项
    .option {
      display: flex;
      height: 48px;
      font-size: 24px;
      cursor: pointer;
      align-items: center;
      justify-content: center;
      border-left: 3px solid #303842;
    }

    /*.option:nth-child(1){
      color: #ffffff;
      background: #363F48;
      border-left: 3px solid #77fd59;
    }*/

    .option:hover, .option:nth-child(1) {
      color: #ffffff;
      background: #363F48;
      border-left: 3px solid #77fd59;
    }

    // 设置
    .settings {
      position: absolute;
      width: 100%;
      display: flex;
      cursor: pointer;
      height: 48px;
      font-size: 24px;
      align-items: center;
      justify-content: center;
      bottom: 20px;
    }

    .settings:hover {
      color: #ffffff;
    }
  }
}

// 容器
.container {
  width: 1180px;
  height: 580px;
  border-radius: 4px;
  box-shadow: 0 3px 10px rgba(0, 0, 0, .92);
}

// 首页
.home {
  display: flex;
  width: 100%;
  height: 100vh;
  align-items: center;
  justify-content: center;
  background: #ECEFFF;
}
</style>